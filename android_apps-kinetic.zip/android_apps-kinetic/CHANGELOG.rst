Changelog
=========

0.2.0 (2015-02-22)
------------------
* First build on indigo

0.1.4 (2013-10-31)
------------------
* use ROS_MAVEN_REPOSITORY
